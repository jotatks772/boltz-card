import React, { useState } from 'react';
import './App.css';

// --- COMPONENTES AUXILIARES ---

const Sidebar = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', icon: 'fas fa-home', label: 'Dashboard' },
    { id: 'deposit', icon: 'fas fa-arrow-down', label: 'Depositar' },
    { id: 'withdraw', icon: 'fas fa-arrow-up', label: 'Sacar' },
    { id: 'referral', icon: 'fas fa-users', label: 'Indique e Ganhe' },
    { id: 'history', icon: 'fas fa-list', label: 'Histórico' },
  ];

  return (
    <nav className="sidebar">
      <div className="brand">
        <i className="fas fa-bolt"></i>
        <span>BOLTZ</span>
      </div>
      <ul className="menu">
        {menuItems.map((item) => (
          <li 
            key={item.id}
            className={`menu-item ${activeTab === item.id ? 'active' : ''}`}
            onClick={() => setActiveTab(item.id)}
          >
            <i className={item.icon}></i> <span>{item.label}</span>
          </li>
        ))}
      </ul>
    </nav>
  );
};

// --- DADOS DA CONTA ---
const AccountSettings = () => {
  return (
    <div className="glass-panel fade-in" style={{ maxWidth: '700px', margin: '0 auto' }}>
      <h2 style={{ marginBottom: '25px', borderBottom: '1px solid #333', paddingBottom: '15px' }}>
        <i className="fas fa-user-cog" style={{ color: '#00ff9d', marginRight: '10px' }}></i>
        Dados da Conta
      </h2>

      <div style={{ display: 'grid', gap: '20px' }}>
        <div className="input-group">
          <label>Nome Completo</label>
          <div className="custom-input" style={{ color: '#ccc', background: '#111' }}>Carlos Junior</div>
        </div>
        <div className="input-group">
          <label>Endereço de Email</label>
          <div className="custom-input" style={{ color: '#ccc', background: '#111' }}>
            carlos.jr@email.com
            <i className="fas fa-check-circle" style={{ color: '#00ff9d', float: 'right', marginTop: '4px' }} title="Verificado"></i>
          </div>
        </div>
        <div className="input-group">
          <label>Número Fiscal (CPF)</label>
          <div className="custom-input" style={{ color: '#ccc', background: '#111', fontFamily: 'monospace' }}>***.456.789-**</div>
        </div>
        <div className="input-group">
          <label>Senha</label>
          <div style={{ display: 'flex', gap: '10px' }}>
            <div className="custom-input" style={{ color: '#ccc', background: '#111' }}>••••••••••••••••</div>
            <button className="btn-small" onClick={() => alert('Função de alterar senha enviada para seu email.')}>Alterar</button>
          </div>
        </div>
        <div className="input-group">
          <label>Região da Conta</label>
          <div className="region-box">
             <span className="flag-icon">🇧🇷</span>
             <span>Brasil</span>
             <span style={{ marginLeft: 'auto', fontSize: '12px', color: '#666', textTransform: 'uppercase' }}>América do Sul</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- NOVA PÁGINA DE ATIVAÇÃO PREMIUM ---
const ActivationPage = ({ onActivate, onCancel }) => {
  const [loading, setLoading] = useState(false);

  const handleProcess = () => {
    setLoading(true);
    setTimeout(() => {
      onActivate();
      setLoading(false);
    }, 2000);
  };

  return (
    <div className="fade-in">
      <div style={{ marginBottom: '20px', cursor: 'pointer', color: '#888', display: 'flex', alignItems: 'center', gap: '10px' }} onClick={onCancel}>
        <i className="fas fa-arrow-left"></i> Voltar para Dashboard
      </div>

      <div className="glass-panel" style={{ padding: '40px' }}>
        <div className="activation-grid">
          
          {/* LADO ESQUERDO: Informações e Venda */}
          <div>
            <span style={{ color: '#00ff9d', textTransform: 'uppercase', fontSize: '12px', letterSpacing: '2px', fontWeight: 'bold' }}>
              Premium Membership
            </span>
            <h1 style={{ fontSize: '36px', marginTop: '10px', marginBottom: '10px' }}>Ative seu Boltz Card</h1>
            <p style={{ color: '#888', lineHeight: '1.6' }}>
              Desbloqueie o poder das criptomoedas no seu dia a dia. Sem anuidade, sem taxas escondidas e com aceitação global.
            </p>

            <div className="benefit-list">
              <div className="benefit-item">
                <div className="benefit-icon"><i className="fas fa-globe-americas"></i></div>
                <div>
                  <div style={{ fontWeight: 'bold', color: '#fff' }}>Aceitação Global</div>
                  <div style={{ fontSize: '12px', color: '#888' }}>Compre em mais de 200 países.</div>
                </div>
              </div>

              <div className="benefit-item">
                <div className="benefit-icon"><i className="fas fa-undo-alt"></i></div>
                <div>
                  <div style={{ fontWeight: 'bold', color: '#fff' }}>Reembolso Instantâneo</div>
                  <div style={{ fontSize: '12px', color: '#888' }}>A taxa de $15 retorna como saldo para você usar.</div>
                </div>
              </div>

              <div className="benefit-item">
                <div className="benefit-icon"><i className="fas fa-shield-alt"></i></div>
                <div>
                  <div style={{ fontWeight: 'bold', color: '#fff' }}>Segurança Máxima</div>
                  <div style={{ fontSize: '12px', color: '#888' }}>Tecnologia 3D Secure e bloqueio via app.</div>
                </div>
              </div>
            </div>

            <div className="price-display">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <span style={{ color: '#ccc' }}>Taxa de Emissão Única</span>
                <span style={{ fontSize: '24px', fontWeight: 'bold', color: '#00ff9d' }}>$ 15.00</span>
              </div>
              <button className="btn-glow" onClick={handleProcess} style={{ opacity: loading ? 0.7 : 1, height: '55px', fontSize: '16px' }}>
                {loading ? (
                   <span><i className="fas fa-spinner fa-spin"></i> Processando Pagamento...</span>
                ) : (
                   <span>Desbloquear Agora <i className="fas fa-arrow-right" style={{ marginLeft: '10px' }}></i></span>
                )}
              </button>
              <p style={{ textAlign: 'center', fontSize: '11px', color: '#666', marginTop: '15px' }}>
                <i className="fas fa-lock"></i> Pagamento seguro criptografado.
              </p>
            </div>
          </div>

          {/* LADO DIREITO: Visual do Cartão Bloqueado */}
          <div className="locked-card-container">
            <div className="lock-overlay">
              <div className="lock-circle">
                <i className="fas fa-lock"></i>
              </div>
              <h3 style={{ textTransform: 'uppercase', letterSpacing: '1px' }}>Cartão Bloqueado</h3>
              <p style={{ fontSize: '12px', color: '#ccc' }}>Ative para visualizar os dados</p>
            </div>
            
            <div className="locked-card-wrapper">
              <div className="premium-card" style={{ display: 'flex', height: '320px', animation: 'none' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <div className="chip"></div>
                  <i className="fas fa-wifi" style={{ transform: 'rotate(90deg)', opacity: 0.7 }}></i>
                </div>
                <div className="card-number" style={{ filter: 'blur(4px)' }}>5412 7512 3412 8842</div>
                <div className="card-details">
                  <div>Titular <strong>SEU NOME AQUI</strong></div>
                  <div style={{ fontSize: '30px' }}><i className="fab fa-cc-mastercard"></i></div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

// --- DASHBOARD ---
const Dashboard = ({ balance, isCardActive, onRequestCard, onNavigate }) => {
  return (
    <div className="fade-in">
      <div className="hero-balance-card">
        <p style={{ color: '#888', fontSize: '14px', textTransform: 'uppercase' }}>Saldo Disponível</p>
        <div className="hero-amount"><span>$</span> {balance.toFixed(2)}</div>
      </div>

      <div className="dashboard-content-grid">
        <div>
          <h3 style={{ marginBottom: '20px' }}>Cartão Boltz</h3>
          {!isCardActive ? (
            <div className="request-card-box">
              <div style={{ fontSize: '40px', color: '#555', marginBottom: '20px' }}><i className="far fa-credit-card"></i></div>
              <h3 style={{ marginBottom: '10px' }}>Solicite seu cartão</h3>
              <p style={{ color: '#666', fontSize: '13px', marginBottom: '25px' }}>Solicite seu cartão físico e virtual agora.</p>
              <button className="btn-glow" style={{ width: 'auto' }} onClick={onRequestCard}>Solicitar Cartão</button>
            </div>
          ) : (
            <div className="premium-card">
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <div className="chip"></div>
                <i className="fas fa-wifi" style={{ transform: 'rotate(90deg)', opacity: 0.7 }}></i>
              </div>
              <div className="card-number">5412 7512 3412 8842</div>
              <div className="card-details">
                <div>Titular <strong>CARLOS JUNIOR</strong></div>
                <div>EXP <strong>09/29</strong></div>
                <div style={{ fontSize: '30px' }}><i className="fab fa-cc-mastercard"></i></div>
              </div>
            </div>
          )}
          <div style={{ marginTop: '40px' }}>
            <h3 style={{ marginBottom: '15px' }}>Meus Ativos</h3>
            <div className="assets-list">
              <AssetRow icon="fas fa-dollar-sign" type="usdt" name="Tether" ticker="USDT" balance={balance.toFixed(2)} usd={balance.toFixed(2)} />
              <AssetRow icon="fab fa-bitcoin" type="btc" name="Bitcoin" ticker="BTC" balance="0.00000" usd="0.00" />
              <AssetRow icon="fab fa-ethereum" type="eth" name="Ethereum" ticker="ETH" balance="0.00000" usd="0.00" />
            </div>
          </div>
        </div>
        <div className="glass-panel" style={{ height: 'fit-content' }}>
          <h3 style={{ marginBottom: '20px' }}>Acesso Rápido</h3>
          <button className="btn-glow" style={{ marginBottom: '15px' }} onClick={() => onNavigate('deposit')}><i className="fas fa-plus"></i> Novo Depósito</button>
          <button className="btn-glow" style={{ borderColor: '#333', color: '#fff' }} onClick={() => onNavigate('referral')}><i className="fas fa-gift"></i> Indicar Amigos</button>
          <div style={{ marginTop: '30px', paddingTop: '20px', borderTop: '1px solid #222' }}>
            <h4 style={{ marginBottom: '10px', fontSize: '14px', color: '#888' }}>Cotação Atual</h4>
            <MarketRow pair="BTC/USD" change="+1.2%" />
            <MarketRow pair="ETH/USD" change="+0.8%" />
          </div>
        </div>
      </div>
    </div>
  );
};

const Deposit = () => {
  const [currency, setCurrency] = useState('BTC');
  const wallets = { 'BTC': 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh', 'USDT': 'TXj71C7656EC7ab88b098defB751B7401B5f6d' };
  const copyToClipboard = () => { navigator.clipboard.writeText(wallets[currency]); alert("Endereço copiado!"); };

  return (
    <div className="glass-panel fade-in" style={{ maxWidth: '600px', margin: '0 auto', textAlign: 'center' }}>
      <h2 style={{ marginBottom: '10px' }}>Depositar Fundos</h2>
      <div className="input-group">
        <label>Selecionar Ativo</label>
        <select className="custom-select" value={currency} onChange={(e) => setCurrency(e.target.value)}>
          <option value="BTC">Bitcoin (BTC)</option>
          <option value="USDT">Tether (USDT TRC20)</option>
        </select>
      </div>
      <div style={{ background: '#fff', padding: '15px', borderRadius: '16px', display: 'inline-block', margin: '20px 0' }}>
        <img src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${wallets[currency]}`} alt="QR Code" style={{ width: '180px', height: '180px' }} />
      </div>
      <div className="input-group">
        <label>Seu Endereço</label>
        <div style={{ background: '#0a0a0a', padding: '15px', borderRadius: '10px', border: '1px solid #333', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '10px', fontFamily: 'monospace', color: '#00ff9d', wordBreak: 'break-all', textAlign: 'left' }}>
          <span style={{ fontSize: '13px' }}>{wallets[currency]}</span>
          <i className="fas fa-copy" style={{ cursor: 'pointer' }} onClick={copyToClipboard}></i>
        </div>
      </div>
    </div>
  );
};

const Referral = () => {
  const copyLink = () => { navigator.clipboard.writeText("boltz.card/invite/carlosjr"); alert("Link copiado!"); };
  return (
    <div className="fade-in">
      <div className="dashboard-content-grid" style={{ marginBottom: '30px' }}>
        <div className="glass-panel" style={{ background: 'linear-gradient(135deg, rgba(0,255,157,0.1), transparent)', borderColor: '#00ff9d', position: 'relative', overflow: 'hidden' }}>
          <i className="fas fa-handshake" style={{ position: 'absolute', right: '-20px', bottom: '-20px', fontSize: '150px', opacity: 0.1, color: '#00ff9d' }}></i>
          <h2 style={{ fontSize: '28px', marginBottom: '10px' }}>Indique e Ganhe <span style={{ color: '#00ff9d' }}>$5 USD</span></h2>
          <p style={{ color: '#ccc', fontSize: '14px', lineHeight: 1.6 }}>Convide amigos. Quando eles ativarem o cartão (depósito de $15), você recebe $5.00.</p>
          <div style={{ marginTop: '30px', display: 'flex', gap: '10px' }}>
            <input type="text" value="boltz.card/invite/carlosjr" readOnly className="custom-input" style={{ fontFamily: 'monospace', color: '#00ff9d' }} />
            <button className="btn-glow" style={{ width: 'auto' }} onClick={copyLink}><i className="fas fa-copy"></i></button>
          </div>
        </div>
        <div className="glass-panel">
          <h3 style={{ marginBottom: '20px' }}>Suas Recompensas</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '15px' }}>
             <StatBox value="12" label="Cliques" />
             <StatBox value="3" label="Cadastros" />
             <StatBox value="$ 10.00" label="Ganho Total" highlight />
          </div>
        </div>
      </div>
      <div className="glass-panel">
        <h3>Histórico de Convites</h3>
        <div style={{ overflowX: 'auto' }}>
          <table>
            <thead><tr><th>Usuário</th><th>Data</th><th>Status</th><th>Recompensa</th></tr></thead>
            <tbody>
              <tr><td>marcos.p***@email.com</td><td>10/12/2023</td><td><span style={{ color: '#00ff9d' }}>Cartão Ativo</span></td><td style={{ color: '#00ff9d' }}>+ $ 5.00</td></tr>
              <tr><td>pendente@email.com</td><td>11/12/2023</td><td><span style={{ color: '#f7931a' }}>Aguardando Depósito</span></td><td style={{ color: '#666' }}>$ 0.00</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const History = ({ transactions }) => (
  <div className="glass-panel fade-in">
    <h3>Histórico Geral</h3>
    <table>
      <thead><tr><th>Status</th><th>Descrição</th><th>Valor</th><th>Data</th></tr></thead>
      <tbody>
        {transactions.length === 0 ? (
          <tr><td colSpan="4" style={{ textAlign: 'center', padding: '30px' }}>Sem transações recentes.</td></tr>
        ) : (
          transactions.map((tx, index) => (
            <tr key={index}><td><span style={{ color: '#00ff9d' }}>● Sucesso</span></td><td>{tx.desc}</td><td style={{ color: '#00ff9d' }}>{tx.amount}</td><td>{tx.date}</td></tr>
          ))
        )}
      </tbody>
    </table>
  </div>
);

// --- COMPONENTES MENORES ---
const AssetRow = ({ icon, type, name, ticker, balance, usd }) => (
  <div className="asset-item">
    <div className="asset-left">
      <div className={`coin-icon icon-${type}`}><i className={icon}></i></div>
      <div><div style={{ fontWeight: 600, fontSize: '14px' }}>{name}</div><div style={{ fontSize: '12px', color: '#888' }}>{ticker}</div></div>
    </div>
    <div><div style={{ fontWeight: 600, textAlign: 'right' }}>{balance}</div><div style={{ fontSize: '12px', color: '#888', textAlign: 'right' }}>$ {usd}</div></div>
  </div>
);
const MarketRow = ({ pair, change }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px', fontSize: '13px' }}><span>{pair}</span><span style={{ color: '#00ff9d' }}>{change}</span></div>
);
const StatBox = ({ value, label, highlight }) => (
  <div style={{ background: highlight ? 'rgba(0, 255, 157, 0.05)' : 'rgba(0,0,0,0.4)', padding: '20px', borderRadius: '12px', border: `1px solid ${highlight ? '#00ff9d' : '#333'}`, textAlign: 'center' }}>
    <div style={{ fontSize: '24px', fontWeight: 700, margin: '5px 0', color: highlight ? '#00ff9d' : '#fff' }}>{value}</div>
    <div style={{ fontSize: '11px', color: '#888', textTransform: 'uppercase' }}>{label}</div>
  </div>
);

// --- APP PRINCIPAL ---
export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [balance, setBalance] = useState(0.00);
  const [isCardActive, setIsCardActive] = useState(false);
  const [transactions, setTransactions] = useState([]);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const handleActivation = () => {
    setBalance(15.00);
    setIsCardActive(true);
    setTransactions(prev => [{ desc: 'Ativação Cartão', amount: '+ $ 15.00', date: 'Agora' }, ...prev]);
    setActiveTab('dashboard');
    alert("Sucesso! Cartão emitido e saldo creditado.");
  };

  const handleMenuClick = (action) => {
    setShowProfileMenu(false);
    if (action === 'logout') {
        if(confirm("Deseja realmente sair?")) alert("Logout realizado (Simulação)");
    } else if (action === 'settings') {
        setActiveTab('settings');
    } else {
        alert(`Navegar para: ${action}`);
    }
  };

  const renderContent = () => {
    if (activeTab === 'activation-page') return <ActivationPage onActivate={handleActivation} onCancel={() => setActiveTab('dashboard')} />;
    switch (activeTab) {
      case 'dashboard': return <Dashboard balance={balance} isCardActive={isCardActive} onRequestCard={() => setActiveTab('activation-page')} onNavigate={setActiveTab} />;
      case 'deposit': return <Deposit />;
      case 'withdraw': return (
          <div className="glass-panel fade-in" style={{ maxWidth: '600px', margin: '0 auto', textAlign: 'center' }}>
            <h2 style={{ marginBottom: '20px' }}>Sacar Fundos</h2>
            <form onSubmit={(e) => { e.preventDefault(); alert('Solicitação enviada!'); }}>
              <div className="input-group"><label>Ativo</label><select className="custom-select"><option>USDT</option><option>BTC</option></select></div>
              <div className="input-group"><label>Endereço</label><input type="text" className="custom-input" placeholder="Endereço da carteira" /></div>
              <div className="input-group"><label>Valor</label><input type="number" className="custom-input" placeholder="0.00" /></div>
              <button className="btn-glow">Confirmar Saque</button>
            </form>
          </div>
        );
      case 'referral': return <Referral />;
      case 'history': return <History transactions={transactions} />;
      case 'settings': return <AccountSettings />;
      default: return <Dashboard balance={balance} isCardActive={isCardActive} onRequestCard={() => setActiveTab('activation-page')} onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="app-container">
      <Sidebar activeTab={activeTab === 'activation-page' ? 'dashboard' : activeTab} setActiveTab={setActiveTab} />
      <main className="main-content">
        <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
          <div className="header-title"><h1 style={{ fontSize: '24px', fontWeight: 400 }}>Painel do Usuário</h1></div>
          <div className="profile-container">
            <div className="user-avatar" onClick={() => setShowProfileMenu(!showProfileMenu)}>CJ</div>
            {showProfileMenu && (
              <div className="profile-dropdown">
                <div className="dropdown-item" onClick={() => handleMenuClick('settings')}><i className="fas fa-user-cog"></i> Dados da Conta</div>
                <div className="dropdown-item" onClick={() => handleMenuClick('Suporte')}><i className="fas fa-headset"></i> Suporte</div>
                <div style={{ height: '1px', background: '#333', margin: '5px 0' }}></div>
                <div className="dropdown-item logout" onClick={() => handleMenuClick('logout')}><i className="fas fa-sign-out-alt"></i> Sair</div>
              </div>
            )}
          </div>
        </header>
        {renderContent()}
      </main>
    </div>
  );
}